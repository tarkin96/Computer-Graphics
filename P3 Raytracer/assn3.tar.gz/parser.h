/* This class parses an obj file.
 * 
 * 
 */ 

#ifndef PARSER_H
#define PARSER_H
#include "Object.h"
class Parser {
	public:
		void read(char*, Object&);
	private:
		
		
};
#endif
