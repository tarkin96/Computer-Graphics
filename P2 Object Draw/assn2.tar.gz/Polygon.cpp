#include "Polygon.h"

//void Polygon::makeEdgeTable(std::vector<std::vector<unsigned int>> faceinfo, std::vector<Vertex> vertices) {
	//WILL IMPLEMENT IF I HAVE TIME
	
//}
